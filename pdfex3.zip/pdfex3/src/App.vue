<script setup>
import { ref, onMounted } from 'vue'
import { usePdfiumEngine } from '@embedpdf/engines/vue'
import { EmbedPDF } from '@embedpdf/core/vue'
import { Viewport } from '@embedpdf/plugin-viewport/vue'
import { Scroller } from '@embedpdf/plugin-scroll/vue'
import { TilingLayer } from '@embedpdf/plugin-tiling/vue'
import { RenderLayer } from '@embedpdf/plugin-render/vue'
import { SelectionLayer } from '@embedpdf/plugin-selection/vue'
import { MarqueeZoom } from '@embedpdf/plugin-zoom/vue'
import { SearchLayer } from '@embedpdf/plugin-search/vue'
import { Rotate } from '@embedpdf/plugin-rotate/vue'
import { GlobalPointerProvider, PagePointerProvider } from '@embedpdf/plugin-interaction-manager/vue'

import { makePluginsFromBuffer } from './EmbedPdfSetup'
import Toolbar from './components/ToolBar.vue'
import DrawerProvider from './components/drawer-system/DrawerProvider.vue'
import Drawer from './components/drawer-system/DrawerTool.vue'
import Search from './components/SearchBar.vue'
import CommentsSidebar from './components/CommentsSidebar.vue'
import ReviewsSidebar from './components/ReviewsSidebar.vue';
import CommentIndicators from './components/CommentIndicators.vue'
import PageControls from './components/PageControls.vue'
import CommentLayer from './comments/CommentLayer.vue'

import { useComments } from './composables/useComments'

const { loadComments } = useComments();
const drawerComponents = [
  { id: 'search',   component: Search,          icon: 'mdi-magnify',          label: 'Search',   position: 'right' },
  { id: 'comments', component: CommentsSidebar, icon: 'mdi-comment-multiple', label: 'Comments', position: 'right' },
  {
    id: 'reviews',
    component: ReviewsSidebar,
    icon: 'mdi-clipboard-text-outline',
    label: 'Reviews',
    position: 'right',
  },
]

const { engine, isLoading } = usePdfiumEngine()
let plugins = ref(null)
const loadingPdf = ref(true)
const loadError = ref('')

async function loadPdf() {
  try {
    //Loading PDF Buffer
    const params = new URLSearchParams(window.location.search);
    const id    = params.get('id', '');
    const type = params.get('type', '');
    const group_key = params.get('group_key', '');
    const name = params.get('name', document.pdf);
    const url = `/api/v2/file/${type}/${id}/${group_key}?purpose=pdfex`;
    const pdfresp = await fetch(url, { credentials: 'include' });
    if (!pdfresp.ok) throw new Error(`HTTP ${pdfresp.status}`);
    const ct = pdfresp.headers.get('content-type') || '';
    if (!ct.includes('application/pdf')) {
      const text = await pdfresp.text().catch(() => '')
      throw new Error(`Expected application/pdf, got: ${ct}\n${text.slice(0, 200)}`)
    }
    const ab = await pdfresp.arrayBuffer()
    plugins = makePluginsFromBuffer(id, name, ab) //Creating Plugin registrations
    window.__PDFEX__ = id; // Setting document id in window object
    console.log('plugins setting is done');
    
    const csrfresp = await fetch('/api/v2/_csrfToken', {credentials: 'include'}) // Getting CSRF tken required for non GET operations
    if (!csrfresp.ok) throw new Error(`HTTP ${csrfresp.status}`);
    const csrfdata = await csrfresp.json();
    window.csrfToken = csrfdata.token;

    const interactionsresp = await fetch(`/api/v2/pdfex/${window.__PDFEX__}/interactions`, {credentials: 'include'}) // Getting document interactions
    if (!interactionsresp.ok) throw new Error(`HTTP ${interactionsresp.status}`);
    const interactionsjson = await interactionsresp.json();
    localStorage.setItem('pdfex-comments', JSON.stringify(interactionsjson));
    loadComments();
  } catch (e) {
    console.error(e)
    loadError.value = e?.message || 'Failed to load PDF'
  } finally {
    loadingPdf.value = false
  }
}

onMounted(loadPdf)
</script>

<template>
  <div id="pdf-viewer" class="h-screen w-screen overflow-hidden">
    <!-- Loading/Error state -->
    <div v-if="isLoading || !engine || loadingPdf || !plugins" class="loading">
      <div v-if="isLoading || !engine">Loading PDF engine…</div>
      <div v-else-if="loadError">Error: {{ loadError }}</div>
      <div v-else>Loading document…</div>
    </div>

    <!-- Viewer -->
    <EmbedPDF v-else :engine="engine" :plugins="plugins">
      <DrawerProvider :components="drawerComponents">
        <v-layout class="fill-height" id="pdf-app-layout">
          <Toolbar />
          <Drawer position="left" />
          <v-main class="fill-height">
            <div class="fill-height position-relative">
              <GlobalPointerProvider>
                <Viewport class="fill-height" style="background-color:#f5f5f5; overflow:auto">
                  <Scroller>
                    <template #default="{ page }">
                      <Rotate :page-size="{ width: page.width, height: page.height }">
                        <PagePointerProvider
                          :page-index="page.pageIndex"
                          :page-width="page.width"
                          :page-height="page.height"
                          :rotation="page.rotation"
                          :scale="page.scale"
                          class="position-absolute"
                        >
                          <RenderLayer :page-index="page.pageIndex" style="pointer-events:none" />
                          <TilingLayer :page-index="page.pageIndex" :scale="page.scale" style="pointer-events:none" />
                          <MarqueeZoom :page-index="page.pageIndex" :scale="page.scale" />
                          <SearchLayer :page-index="page.pageIndex" :scale="page.scale" />
                          <SelectionLayer :page-index="page.pageIndex" :scale="page.scale" style="pointer-events:auto; z-index:5" />
                          <CommentLayer :page-index="page.pageIndex" />
                          <CommentIndicators :page-index="page.pageIndex" :page-width="page.width" :page-height="page.height" :scale="page.scale" />
                        </PagePointerProvider>
                      </Rotate>
                    </template>
                  </Scroller>
                  <PageControls />
                </Viewport>
              </GlobalPointerProvider>
            </div>
          </v-main>
          <Drawer position="right" />
        </v-layout>
      </DrawerProvider>
    </EmbedPDF>
  </div>
</template>

<style>
html, body, #app { height: 100%; margin: 0; }
#pdf-viewer, #pdf-viewer * { -webkit-user-select: text; user-select: text; }
.loading { padding: 12px; font-family: system-ui, sans-serif; }
</style>
