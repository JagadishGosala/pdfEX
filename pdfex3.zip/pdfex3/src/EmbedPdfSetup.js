import { createPluginRegistration } from '@embedpdf/core'
import { LoaderPluginPackage } from '@embedpdf/plugin-loader/vue'
import { ViewportPluginPackage } from '@embedpdf/plugin-viewport/vue'
import { ScrollPluginPackage } from '@embedpdf/plugin-scroll/vue'
import { TilingPluginPackage } from '@embedpdf/plugin-tiling/vue'
import { RenderPluginPackage } from '@embedpdf/plugin-render/vue'
import { SearchPluginPackage } from '@embedpdf/plugin-search/vue'
import { FullscreenPluginPackage } from '@embedpdf/plugin-fullscreen/vue'
import { PanPluginPackage } from '@embedpdf/plugin-pan/vue'
import { RotatePluginPackage } from '@embedpdf/plugin-rotate/vue'
import { ExportPluginPackage } from '@embedpdf/plugin-export/vue'
import { SpreadPluginPackage } from '@embedpdf/plugin-spread/vue'
import { PrintPluginPackage } from '@embedpdf/plugin-print/vue'
import { InteractionManagerPluginPackage } from '@embedpdf/plugin-interaction-manager/vue'
import { SelectionPluginPackage } from '@embedpdf/plugin-selection/vue'
import { ZoomMode, ZoomPluginPackage } from '@embedpdf/plugin-zoom/vue'

function commonPlugins() {
  return [
    createPluginRegistration(ViewportPluginPackage),
    createPluginRegistration(ScrollPluginPackage),
    createPluginRegistration(TilingPluginPackage, { tileSize: 768, overlapPx: 2.5, extraRings: 0 }),
    createPluginRegistration(RenderPluginPackage),
    createPluginRegistration(SearchPluginPackage),
    createPluginRegistration(ZoomPluginPackage, { defaultZoomLevel: ZoomMode.FitPage }),
    createPluginRegistration(FullscreenPluginPackage),
    createPluginRegistration(PanPluginPackage),
    createPluginRegistration(RotatePluginPackage),
    createPluginRegistration(ExportPluginPackage),
    createPluginRegistration(SpreadPluginPackage),
    createPluginRegistration(PrintPluginPackage),
    createPluginRegistration(InteractionManagerPluginPackage),
    createPluginRegistration(SelectionPluginPackage),
  ]
}

export function makePluginsFromBuffer(id, name, buff) {
  const buffer = buff instanceof ArrayBuffer ? new Uint8Array(buff) : buff;
  return [
    createPluginRegistration(LoaderPluginPackage, {
      loadingOptions: {
        type: 'buffer',
        pdfFile: { 
          id: id, 
          name: name,
          content: buffer 
        },
      },
    }),
    ...commonPlugins(),
  ]
}
