<!-- <script setup>
import { onMounted, onUnmounted } from 'vue'
import { useRegistry } from '@embedpdf/core/vue'
import { SELECTION_PLUGIN_ID } from '@embedpdf/plugin-selection/vue'

const registryRef = useRegistry()?.registry

async function resolveSelectedText(maybe, timeoutMs = 800) {
  if (typeof maybe === 'string') return maybe
  if (maybe && typeof maybe.then === 'function') {
    const r = await maybe
    const arr = r?.state?.result
    return Array.isArray(arr) ? arr.join(' ') : ''
  }
  const start = performance.now()
  while (performance.now() - start < timeoutMs) {
    const arr = maybe?.state?.result
    if (Array.isArray(arr)) return arr.join(' ')
    await new Promise(r => setTimeout(r, 30))
  }
  const arr = maybe?.state?.result
  return Array.isArray(arr) ? arr.join(' ') : ''
}

// Build a union bbox from plugin rects [{origin:{x,y}, size:{width,height}}]
function rectsToUnionBBox(rects) {
  if (!Array.isArray(rects) || rects.length === 0) return null
  const left   = Math.min(...rects.map(r => r.origin.x))
  const top    = Math.min(...rects.map(r => r.origin.y))
  const right  = Math.max(...rects.map(r => r.origin.x + r.size.width))
  const bottom = Math.max(...rects.map(r => r.origin.y + r.size.height))
  return { origin: { x: left, y: top }, size: { width: right - left, height: bottom - top } }
}

/**
 * Replacement getRangeInfo that uses the Selection plugin only (no DOM Range).
 * Returns:
 * {
 *   pageIndex1: number,   // 1-based
 *   pageIndex0: number,   // 0-based
 *   rects: PdfRect[],     // plugin page coords: { origin:{x,y}, size:{width,height} }
 *   bbox:  PdfRect,       // union of rects in same coord system
 *   units: 'page'         // coords are page-relative
 * }
 */
async function getRangeInfo(maxWaitMs = 600) {
  const api = registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
  if (!api) return null

  const start = performance.now()
  let pageIndex1 = null
  let rects = null

  // Keep polling for selection geometry until it’s populated or we time out
  while ((performance.now() - start) < maxWaitMs) {
    try {
      // Preferred: highlight rects map { "1": [rect,...], ... } (pages are 1-based)
      const hi = api.getHighlightRects?.()
      console.log('difvfiu    ', api.getHighlightRects?.())
      if (hi && typeof hi === 'object') {
        // pick the first page that has rects
        const pages = Object.keys(hi).filter(k => Array.isArray(hi[k]) && hi[k].length > 0)
        if (pages.length > 0) {
          pageIndex1 = parseInt(pages[0], 10)
          rects = hi[pages[0]]
          console.log(rects)
        }
      }

      // Fallback: bounding rects [{ page: number, rect }]
      if (!rects || rects.length === 0) {
        const bbs = api.getBoundingRects?.()
        if (Array.isArray(bbs) && bbs.length > 0) {
          // take first page result
          const first = bbs.find(item => item?.rect && typeof item.page === 'number')
          if (first) {
            pageIndex1 = first.page
            rects = [first.rect]
          }
        }
      }
    } catch {
      // ignore transient errors while selection is stabilizing
    }

    if (rects && rects.length) break
    await new Promise(requestAnimationFrame)
  }

  if (!rects || !rects.length || !pageIndex1) return null

  const bbox = rectsToUnionBBox(rects)
  return {
    pageIndex1,
    pageIndex0: pageIndex1 - 1,
    rects,            // in plugin "page" coordinates
    bbox,             // union in same coordinates
    units: 'page'
  }
}

onMounted(() => {
  let t = 0
  const onPointerUp = async () => {
    // tiny debounce to avoid duplicate pointerups
    clearTimeout(t)
    t = setTimeout(async () => {
      const api = await registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
      if (!api) return

      // Selected text (handles WorkerTask/thenable)
      const maybe = api.getSelectedText?.()
      const selectedText = await resolveSelectedText(maybe)
      if (!selectedText || !selectedText.trim()) return

      // Geometry from plugin
      const info = await getRangeInfo()
      console.log('[EmbedPDF] selectedText:', selectedText)
      console.log('[EmbedPDF] range info (plugin-based):', info)

      // For reference (optional)
      // console.log('getHighlightRects:', api.getHighlightRects?.())
      // console.log('getBoundingRects:', api.getBoundingRects?.())

      // Example usage later:
      // if (info) commentStore.add({
      //   text: selectedText,
      //   pageIndex: info.pageIndex0,
      //   rectsNorm: info.rects.map(r => ({
      //     x: r.origin.x / pageWidth,      // you’d need pageWidth/pageHeight here
      //     y: r.origin.y / pageHeight,
      //     w: r.size.width / pageWidth,
      //     h: r.size.height / pageHeight,
      //   })),
      // })
    }, 10)
  }

  document.addEventListener('pointerup', onPointerUp, true)
  onUnmounted(() => document.removeEventListener('pointerup', onPointerUp, true))
})
</script>
 -->

<template>
  <div>
    <!-- Floating Add Comment Icon -->
    <button
      v-if="showIcon"
      class="absolute bg-blue-500 text-white rounded-full p-2 shadow"
      :style="{ top: iconPos.y + 'px', left: iconPos.x + 'px' }"
      @click="openSidebar"
    >
      💬
    </button>
    <!-- Sidebar -->
    <div
      v-if="sidebarOpen"
      class="fixed top-0 right-0 w-80 h-full bg-gray-100 shadow-lg p-4 flex flex-col"
    >
      <h2 class="font-bold mb-2">Add Comment</h2>
      <p class="text-sm bg-white p-2 rounded border mb-2">{{ selectedText }}</p>
      <input
        v-model="newComment"
        @keyup.enter="saveComment"
        placeholder="Type your comment..."
        class="border p-2 rounded mb-2"
      />
      <button
        @click="saveComment"
        class="bg-green-500 text-white px-4 py-2 rounded"
      >
        Save
      </button>

      <div class="mt-4">
        <h3 class="font-semibold">All Comments</h3>
        <ul>
          <li
            v-for="(c, i) in comments"
            :key="i"
            class="border-b py-1 text-sm"
          >
            <strong>{{ c.text }}</strong>
            <br />
            <span class="text-gray-600">{{ c.comment }}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>


 <script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { useRegistry } from '@embedpdf/core/vue'
import { SELECTION_PLUGIN_ID } from '@embedpdf/plugin-selection/vue'
const registryRef = useRegistry()?.registry

const showIcon = ref(true)
const iconPos = ref({ x: 0, y: 0 })
const selectedText = ref("")
const sidebarOpen = ref(false)
const newComment = ref("")
const comments = ref([]) // store all saved comments

async function resolveSelectedText(maybe, timeoutMs = 800) {
  if (typeof maybe === 'string') return maybe
  if (maybe && typeof maybe.then === 'function') {
    const r = await maybe
    const arr = r?.state?.result
    return Array.isArray(arr) ? arr.join(' ') : ''
  }
  const start = performance.now()
  while (performance.now() - start < timeoutMs) {
    const arr = maybe?.state?.result
    if (Array.isArray(arr)) return arr.join(' ')
    await new Promise(r => setTimeout(r, 30))
  }
  const arr = maybe?.state?.result
  return Array.isArray(arr) ? arr.join(' ') : ''
}

// Build a union bbox from plugin rects [{origin:{x,y}, size:{width,height}}]
function rectsToUnionBBox(rects) {
  if (!Array.isArray(rects) || rects.length === 0) return null
  const left   = Math.min(...rects.map(r => r.origin.x))
  const top    = Math.min(...rects.map(r => r.origin.y))
  const right  = Math.max(...rects.map(r => r.origin.x + r.size.width))
  const bottom = Math.max(...rects.map(r => r.origin.y + r.size.height))
  return { origin: { x: left, y: top }, size: { width: right - left, height: bottom - top } }
}

function openSidebar() {
  sidebarOpen.value = true
  newComment.value = ""
}


function saveComment() {
  if (!newComment.value.trim()) return
  comments.value.push({
    text: selectedText.value,
    comment: newComment.value
  })
  console.log('comments', comments);
  newComment.value = ""
  sidebarOpen.value = false
  showIcon.value = false
}


/**
 * getRangeInfo using Selection plugin ONLY (no DOM Range).
 * Treats pages as 0-based (EmbedPDF default).
 * Returns:
 * {
 *   pageIndex0: number,        // 0-based page index
 *   rects: PdfRect[],          // plugin page coords: { origin:{x,y}, size:{width,height} }
 *   bbox:  PdfRect|null,       // union of rects (same coords)
 *   units: 'page'              // coords are page-relative
 * }
 */
async function getRangeInfo(maxWaitMs = 600) {
  const api = registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
  if (!api) return null

  const start = performance.now()
  let pageIndex0 = null
  let rects = null

  // Poll until geometry appears or timeout
  while ((performance.now() - start) < maxWaitMs) {
    try {
      // Preferred: highlight rects map { "0": [rect,...], "1": [rect,...], ... } (0-based keys)
      const hi = api.getHighlightRects?.()
      if (hi && typeof hi === 'object') {
        const pages = Object.keys(hi)
          .filter(k => Array.isArray(hi[k]) && hi[k].length > 0)
          // Ensure numeric sort of 0-based page keys
          .sort((a, b) => parseInt(a, 10) - parseInt(b, 10))
        if (pages.length > 0) {
          pageIndex0 = parseInt(pages[0], 10)      // 0-based
          console.log('pageIndex09', pageIndex0);
          rects = hi[pages[0]]
        }
      }

      // Fallback: bounding rects [{ page: number(0-based), rect }]
      if (!rects || rects.length === 0) {
        const bbs = api.getBoundingRects?.()
        if (Array.isArray(bbs) && bbs.length > 0) {
          const first = bbs.find(item => item?.rect != null && typeof item.page === 'number')
          if (first) {
            pageIndex0 = first.page                  // already 0-based
            console.log('pageIndex09 after', pageIndex0);
            rects = [first.rect]
          }
        }
      }
    } catch {
      // tolerate transient errors while selection stabilizes
    }

    if (rects && rects.length) break
    await new Promise(requestAnimationFrame)
  }
  if (!rects || !rects.length || pageIndex0 == null) return null
  const bbox = rectsToUnionBBox(rects)
  return {
    pageIndex0,   // 0-based index
    rects,     // plugin page coordinates
    bbox,         // union bbox in same coordinates
    units: 'page'
  }
}

onMounted(() => {
  let t = 0
  const onPointerUp = async () => {
    // tiny debounce to avoid duplicate pointerups
    clearTimeout(t)
    t = setTimeout(async () => {
      const api = await registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
      if (!api) return

      // 1) Selected text (handles WorkerTask/thenable)
      const maybe = api.getSelectedText?.()
      const text = await resolveSelectedText(maybe)
      if (!text || !text.trim()) {
        return
      }

      // 2) Geometry from plugin (0-based)
      const info = await getRangeInfo()
      console.log('[EmbedPDF] selectedText:', text)
      console.log('[EmbedPDF] range info (0-based):', info)
      if (!text || !text.trim()) {
        showIcon.value = false
        return
      }
      if (!info) return

      selectedText.value = text
      // place icon near bbox top-right
      iconPos.value = {
        x: info.bbox.origin.x + info.bbox.size.width + 10,
        y: info.bbox.origin.y
      }
      showIcon.value = true      
      // if (info) {
      //   const pageEl = document.querySelector(`[data-page-index="${info.pageIndex0}"]`)
      //   if (pageEl) {
      //     const rect = pageEl.getBoundingClientRect()
      //     iconPos.value = {
      //       x: rect.left + info.bbox.origin.x + info.bbox.size.width + 10,
      //       y: rect.top + info.bbox.origin.y
      //     }
      //     showIcon.value = true
      //   }
      // }

     
      // Optional raw debug:
      // console.log('getHighlightRects (0-based expected):', api.getHighlightRects?.())
      // console.log('getBoundingRects (0-based expected):', api.getBoundingRects?.())

      // Example (when you have pageWidth/pageHeight in scope):
      // if (info) {
      //   const { pageIndex0, rects } = info
      //   const rectsNorm = rects.map(r => ({
      //     x: r.origin.x / pageWidth,
      //     y: r.origin.y / pageHeight,
      //     w: r.size.width / pageWidth,
      //     h: r.size.height / pageHeight,
      //   }))
      //   commentStore.add({ text: selectedText, pageIndex: pageIndex0, rectsNorm })
      // }
    }, 10)
  }

  document.addEventListener('pointerup', onPointerUp, true)
  onUnmounted(() => document.removeEventListener('pointerup', onPointerUp, true))
})
</script>

