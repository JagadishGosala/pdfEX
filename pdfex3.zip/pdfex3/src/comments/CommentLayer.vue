<template>
  <div>
    <!-- Floating Add Comment Icon -->
    <button
      v-if="showIcon"
      class="comment-icon-container absolute bg-blue-500 text-white rounded-full p-2 shadow-lg hover:bg-blue-600 transition-colors z-10"
      :style="{ top: iconPos.y + 'px', left: iconPos.x + 'px' }"
      @click="openCommentsSidebar"
      title="Add comment"
    >
      <v-icon size="16" color="white">mdi-comment-plus</v-icon>
    </button>
  </div>
</template>

<script setup>
  import { ref, onMounted, onUnmounted, inject, watch } from 'vue'
  import { useRegistry } from '@embedpdf/core/vue'
  import { SELECTION_PLUGIN_ID } from '@embedpdf/plugin-selection/vue'
  import { useComments } from '../composables/useComments.js'
  
  const registryRef = useRegistry()?.registry
  const drawerContext = inject('drawerContext')
  const { setSelection, clearSelection, currentSelection } = useComments()

  const showIcon = ref(false)
  const iconPos = ref({ x: 0, y: 0 })
  const selectedText = ref("")
  const currentPageIndex = ref(null)

  // Watch for selection changes to hide icon when cleared
  watch(currentSelection, (newSelection) => {
    if (!newSelection.text) {
      showIcon.value = false
    }
  }, { deep: true })

  function openCommentsSidebar() {
    if (!selectedText.value.trim()) return
    drawerContext.showComponent('comments')
  }

async function resolveSelectedText(maybe, timeoutMs = 800) {
  if (typeof maybe === 'string') return maybe
  if (maybe && typeof maybe.then === 'function') {
    const r = await maybe
    const arr = r?.state?.result
    return Array.isArray(arr) ? arr.join(' ') : ''
  }
  const start = performance.now()
  while (performance.now() - start < timeoutMs) {
    const arr = maybe?.state?.result
    if (Array.isArray(arr)) return arr.join(' ')
    await new Promise(r => setTimeout(r, 30))
  }
  const arr = maybe?.state?.result
  return Array.isArray(arr) ? arr.join(' ') : ''
}

function rectsToUnionBBox(rects) {
  if (!Array.isArray(rects) || rects.length === 0) return null
  const left   = Math.min(...rects.map(r => r.origin.x))
  const top    = Math.min(...rects.map(r => r.origin.y))
  const right  = Math.max(...rects.map(r => r.origin.x + r.size.width))
  const bottom = Math.max(...rects.map(r => r.origin.y + r.size.height))
  return { origin: { x: left, y: top }, size: { width: right - left, height: bottom - top } }
}

async function getRangeInfo(maxWaitMs = 600) {
  const api = registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
  if (!api) return null

  const start = performance.now()
  let pageIndex0 = null
  let rects = null

  // Poll until geometry appears or timeout
  while ((performance.now() - start) < maxWaitMs) {
    try {
      // Preferred: highlight rects map { "0": [rect,...], "1": [rect,...], ... } (0-based keys)
      const hi = api.getHighlightRects?.()
      if (hi && typeof hi === 'object') {
        const pages = Object.keys(hi)
          .filter(k => Array.isArray(hi[k]) && hi[k].length > 0)
          // Ensure numeric sort of 0-based page keys
          .sort((a, b) => parseInt(a, 10) - parseInt(b, 10))
        if (pages.length > 0) {
          pageIndex0 = parseInt(pages[0], 10)      // 0-based
          // console.log('pageIndex09', pageIndex0);
          rects = hi[pages[0]]
        }
      }

      // Fallback: bounding rects [{ page: number(0-based), rect }]
      if (!rects || rects.length === 0) {
        const bbs = api.getBoundingRects?.()
        if (Array.isArray(bbs) && bbs.length > 0) {
          const first = bbs.find(item => item?.rect != null && typeof item.page === 'number')
          if (first) {
            pageIndex0 = first.page                  // already 0-based
            // console.log('pageIndex09 after', pageIndex0);
            rects = [first.rect]
          }
        }
      }
    } catch {
      // tolerate transient errors while selection stabilizes
    }

    if (rects && rects.length) break
    await new Promise(requestAnimationFrame)
  }
  if (!rects || !rects.length || pageIndex0 == null) return null
  const bbox = rectsToUnionBBox(rects)
  return {
    pageIndex0,   // 0-based index
    rects,     // plugin page coordinates
    bbox,         // union bbox in same coordinates
    units: 'page'
  }
}


onMounted(() => {
    let t = 0
  const onPointerUp = async () => {
    // tiny debounce to avoid duplicate pointerups
    clearTimeout(t)
    t = setTimeout(async () => {
      const api = await registryRef?.value?.getPlugin(SELECTION_PLUGIN_ID)?.provides?.()
      if (!api) return

      // 1) Selected text (handles WorkerTask/thenable)
      const maybe = api.getSelectedText?.()
      const text = await resolveSelectedText(maybe)
      if (!text || !text.trim()) {
        showIcon.value = false
        clearSelection()
        return
      }

      // 2) Geometry from plugin (0-based)
      const info = await getRangeInfo()
      // console.log('[EmbedPDF] selectedText:', text)
      // console.log('[EmbedPDF] range info (0-based):', info)
      if (!text || !text.trim()) {
        showIcon.value = false
        clearSelection()
        return
      }
      if (!info) return

      selectedText.value = text
      currentPageIndex.value = info.pageIndex0
      
      // Set the selection in the composable immediately with text position
      setSelection(text, info.pageIndex0, info.bbox)
      // console.log('[CommentLayer] Selection set:', { text, pageIndex: info.pageIndex0, bbox: info.bbox })
      
      // Don't automatically open the sidebar - let user decide when to open it
      // drawerContext.showComponent('comments')
      
      if (info) {
        const pageEl = document.querySelector(`[data-page-index="${info.pageIndex0}"]`)
        if (pageEl) {
          const pageRect = pageEl.getBoundingClientRect()

          // Scale factors: PDF coordinates → DOM coordinates
          const scaleX = pageRect.width / api.getPageWidth(info.pageIndex0)
          const scaleY = pageRect.height / api.getPageHeight(info.pageIndex0)

          // Convert PDF bbox → DOM coords
          const absLeft = pageRect.left + info.bbox.origin.x * scaleX
          const absTop  = pageRect.top + info.bbox.origin.y * scaleY
          const absRight = absLeft + info.bbox.size.width * scaleX

          // place comment icon slightly to the right of the selection
          iconPos.value = {
            x: absRight + 12,
            y: absTop
          }
          showIcon.value = true
        }
      }
    }, 10)
  }

  const onClickOutside = (event) => {
    if (showIcon.value && !event.target.closest('.comment-icon-container')) {
      showIcon.value = false
      clearSelection()
    }
  }
   
    document.addEventListener('pointerup', onPointerUp, true)
    document.addEventListener('click', onClickOutside, true)
    onUnmounted(() => {
      document.removeEventListener('pointerup', onPointerUp, true)
      document.removeEventListener('click', onClickOutside, true)
    })
})
</script>