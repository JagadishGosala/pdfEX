<!-- <script setup>
import { computed } from 'vue'

// eslint-disable-next-line
const props = defineProps({
  anchor: { type: Object, required: true },
  visible: { type: Boolean, default: false },
})

// ✅ declare emits
// eslint-disable-next-line
const emit = defineEmits(['add-comment'])

const style = computed(() => ({ /* ... */ }))
</script>

<template>
  <div :style="style" class="epdf-comment-popover">
    <button
      class="epdf-popover-btn"
      title="Add comment"
      @click="emit('add-comment')"
    >
      🗨️
    </button>
  </div>
</template>

<style>
.epdf-comment-popover {
  background: white;
  border: 1px solid rgba(0,0,0,.12);
  border-radius: 8px;
  padding: 4px;
  box-shadow: 0 6px 18px rgba(0,0,0,.15);
}
.epdf-popover-btn {
  border: 0;
  background: transparent;
  cursor: pointer;
  font-size: 16px;
  line-height: 1;
  padding: 4px 6px;
}
.epdf-popover-btn:hover {
  filter: brightness(0.9);
}
</style> -->
