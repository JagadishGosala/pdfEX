<template>
  <div class="comment-indicators">
    <!-- Render comment indicators for this page -->
    <div
      v-for="comment in pageComments"
      :key="comment.id"
      class="comment-indicator"
      :data-comment-id="comment.id"
      :style="getIndicatorStyle(comment)"
      @click="navigateToComment(comment)"
      :title="`Comment: ${comment.comment}`"
    >
      <v-icon size="12" color="white">mdi-comment-text</v-icon>
    </div>
  </div>
</template>

<script setup>
import { computed, inject } from 'vue';
import { useComments } from '../composables/useComments.js';

// eslint-disable-next-line no-undef
const props = defineProps({
  pageIndex: { type: Number, required: true },
  pageWidth: { type: Number, required: true },
  pageHeight: { type: Number, required: true },
  scale: { type: Number, required: true },
});

const drawerContext = inject('drawerContext');
const { getAllComments, highlightComment } = useComments();

// Get comments for this specific page
const pageComments = computed(() => {
  return getAllComments().filter(comment => comment.pageIndex === props.pageIndex);
});

// Calculate indicator position based on comment text position
function getIndicatorStyle(comment) {
  if (!comment?.textPosition || !comment.textPosition.origin || !comment.textPosition.size) {
    // Fallback position if no text position stored
    return {
      position: 'absolute',
      top: '10px',
      right: '10px',
      zIndex: 10,
      cursor: 'pointer',
      backgroundColor: 'rgba(255, 175, 56, 0.9)',
      borderRadius: '50%',
      width: '20px',
      height: '20px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
    };
  }

  // Calculate position based on stored text position
  const scaleX = (typeof props.scale === 'number' && isFinite(props.scale)) ? props.scale : 1;
  const scaleY = scaleX;
  
  const x = (Number(comment.textPosition.origin.x) || 0) * scaleX;
  const y = (Number(comment.textPosition.origin.y) || 0) * scaleY;
  const width = (Number(comment.textPosition.size.width) || 0) * scaleX;
  // eslint-disable-next-line no-unused-vars
  const height = (Number(comment.textPosition.size.height) || 0) * scaleY;

  return {
    position: 'absolute',
    left: `${x + width - 10}px`,
    top: `${y - 5}px`,
    zIndex: 10,
    cursor: 'pointer',
    backgroundColor: 'rgba(255, 193, 7, 0.9)',
    borderRadius: '50%',
    width: '20px',
    height: '20px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 2px 4px rgba(0,0,0,0.2)',
  };
}

// Navigate to the comment in the sidebar
// eslint-disable-next-line no-unused-vars
function navigateToComment(comment) {
  // Open the comments sidebar first so DOM exists
  drawerContext.showComponent('comments');
  // Set highlight immediately and again after a tick to ensure sidebar can catch it
  highlightComment(comment.id);
  requestAnimationFrame(() => highlightComment(comment.id));
  setTimeout(() => highlightComment(comment.id), 120);
}
</script>

<style scoped>
.comment-indicators {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.comment-indicator {
  pointer-events: auto;
  transition: transform 0.2s ease;
}

.comment-indicator:hover {
  transform: scale(1.1);
}
</style>
