<script setup>
import { ref, computed, watch, nextTick, onMounted } from 'vue';
import { inject } from 'vue';
import { useComments } from '../composables/useComments.js';

const drawerContext = inject('drawerContext');
const { currentSelection, addComment, deleteComment, getAllComments, clearSelection, highlightedComment, highlightComment } = useComments();

const newComment = ref('');
const listRef = ref(null);

// Debug: Watch for changes in currentSelection
// watch(currentSelection, (newSelection) => {
//   console.log('[CommentsSidebar] Selection changed:', newSelection);
// }, { deep: true });

// Get all comments
const allComments = computed(() => getAllComments());

// Add a new comment
function handleAddComment() {
  const comment = addComment(newComment.value);
  if (comment) {
    newComment.value = '';
    
    // Clear the selection after successful comment addition
    clearSelection();
    
    // Close the sidebar after adding comment (now on right side)
    drawerContext.hideComponent('right');
  }
}

// Delete a comment
function handleDeleteComment(commentId) {
  deleteComment(commentId);
}

function scrollSidebarToComment(commentId) {
  const start = performance.now();
  function tryScroll() {
    const container = listRef.value || document.querySelector('.comments-sidebar .comments-list');
    const el = container ? container.querySelector(`[data-comment-id="${commentId}"]`) : document.querySelector(`[data-comment-id="${commentId}"]`);
    if (container && el) {
      try {
        const containerRect = container.getBoundingClientRect();
        const elRect = el.getBoundingClientRect();
        const offset = (elRect.top - containerRect.top) - (container.clientHeight / 2) + (elRect.height / 2);
        container.scrollTo({ top: container.scrollTop + offset, behavior: 'smooth' });
        return;
      } catch {console.log('hehee')}
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      return;
    }
    if (performance.now() - start < 800) {
      requestAnimationFrame(tryScroll);
    }
  }
  nextTick(() => requestAnimationFrame(tryScroll));
}

// Watch for highlighted comment changes and scroll to it
watch(highlightedComment, (commentId) => {
  if (commentId) {
    scrollSidebarToComment(commentId);
  }
}, { flush: 'post' });

// If the sidebar mounts with a highlighted comment already set, scroll to it
onMounted(() => {
  if (highlightedComment && highlightedComment.value) {
    scrollSidebarToComment(highlightedComment.value);
  }
});

function scrollPdfToComment(comment) {
  try {
    // Prefer scrolling to the exact indicator element if available
    const indicator = document.querySelector(`.comment-indicator[data-comment-id="${comment.id}"]`)
    if (indicator && indicator.scrollIntoView) {
      indicator.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' })
      return
    }
  } catch {console.log('yeehawww')}
  try {
    // Fallback: scroll the page containing the comment into view
    const pageEl = document.querySelector(`[data-page-index="${comment.pageIndex}"]`)
    if (pageEl && pageEl.scrollIntoView) {
      pageEl.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  } catch {console.log('woohoo')}
}

function handleCommentClick(comment) {
  highlightComment(comment.id);
  scrollPdfToComment(comment);
}
</script>

<template>
  <div class="comments-sidebar pa-3">
    <div v-if="currentSelection.text" class="mb-4">
      <v-card variant="outlined" class="pa-3 mb-3">
        <p class="text-body-2 mb-0">{{ currentSelection.text }}</p>
      </v-card>
      
      <v-textarea
        v-model="newComment"
        label="Add a comment..."
        variant="outlined"
        rows="3"
        density="compact"
        hide-details
        class="mb-3"
        @keydown.ctrl.enter="handleAddComment"
      />
      <v-btn
        color="primary"
        variant="flat"
        size="small"
        @click="handleAddComment"
        block
      >
        Add Comment
      </v-btn>
    </div>

    <!-- No Selection State -->
    <div v-else class="text-center pa-4">
      <v-icon size="48" color="grey-lighten-1" class="mb-2">mdi-comment-outline</v-icon>
      <p class="text-body-2 text-medium-emphasis">
        Select text in the PDF to add comments
      </p>
    </div>

    <v-divider class="my-4" />

    <!-- Comments List -->
    <div>
      <h3 class="text-h6 mb-3">All Comments</h3>
      
      <div v-if="allComments.length === 0" class="text-center pa-4">
        <v-icon size="32" color="grey-lighten-1" class="mb-2">mdi-comment-multiple-outline</v-icon>
        <p class="text-body-2 text-medium-emphasis">No comments yet</p>
      </div>
      
      <div v-else class="comments-list" ref="listRef">
        <v-card
          v-for="comment in allComments"
          :key="comment.id"
          :data-comment-id="comment.id"
          variant="outlined"
          class="mb-3 pa-3 comment-card"
          :class="{ 
            'border-primary': comment.pageIndex === currentSelection.pageIndex,
            'highlighted-comment': highlightedComment === comment.id || highlightedComment?.value === comment.id 
          }"
          @click="handleCommentClick(comment)"
        >
          <div class="d-flex justify-space-between align-start mb-2">
            <v-chip size="small" variant="text" color="primary">
              Page {{ comment.pageIndex + 1 }}
            </v-chip>
            <v-btn
              icon="mdi-delete"
              variant="text"
              size="x-small"
              color="error"
              @click.stop="handleDeleteComment(comment.id)"
            />
          </div>
          
          <div class="text-body-2 text-medium-emphasis mb-2">
            "{{ comment.text }}"
          </div>
          
          <div class="text-body-2">
            {{ comment.comment }}
          </div>
          
          <div class="text-caption text-medium-emphasis mt-2">
            {{ new Date(comment.timestamp).toLocaleString() }}
          </div>
        </v-card>
      </div>
    </div>
  </div>
</template>

<style scoped>
.comments-sidebar {
  height: 100%;
  overflow-y: auto;
}

.comments-list {
  max-height: 400px;
  overflow-y: auto;
}

.border-primary {
  border-color: rgb(var(--v-theme-primary)) !important;
}

.highlighted-comment {
  background-color: rgba(255, 193, 7, 0.1) !important;
  border-color: #ffc107 !important;
  border-width: 2px !important;
  transform: scale(1.02);
  transition: all 0.2s ease;
}

.comment-card {
  cursor: pointer;
  transition: all 0.2s ease;
}

.comment-card:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
</style>
