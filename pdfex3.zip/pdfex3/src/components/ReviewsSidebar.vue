<script setup>
import { ref, computed, onMounted } from 'vue'

const reviews = ref([])
const loading = ref(false)
const error = ref(null)

function normalizeStatus(s) {
  const v = (s || '').toLowerCase()
  if (v.includes('not')) return 'not'
  if (v.includes('partial')) return 'partially'
  if (v.includes('align')) return 'aligned'
  return 'unknown'
}

const counts = computed(() => {
  return reviews.value.reduce((acc, r) => {
    const s = normalizeStatus(r.contract_review)
    acc[s] = (acc[s] || 0) + 1
    return acc
  }, { aligned: 0, partially: 0, not: 0 })
})

function statusIcon(status) {
  const s = normalizeStatus(status)
  if (s === 'aligned') return { icon: 'mdi-check-circle-outline', color: 'success' }
  if (s === 'partially') return { icon: 'mdi-alert-circle-outline', color: 'warning' }
  return { icon: 'mdi-close-circle-outline', color: 'error' }
}

async function fetchReviews() {
  loading.value = true
  error.value = null
  
  // Get document ID from URL search parameters (same way as App.vue)
  const params = new URLSearchParams(window.location.search)
  const documentId = params.get('id')
  
  if (!documentId) {
    error.value = 'Document ID not found in URL'
    loading.value = false
    return
  }
  try {
    console.log('sending for review section in backend');
    const { csrfToken } = window;
    const headers = { 
      'Content-Type': 'application/json', 
      'X-CSRF-TOKEN': csrfToken 
    }
    const url = `/api/v2/document/${documentId}/clauseheadings`;
    const resp = await fetch(url, {
      method: 'GET',
      headers: headers,
      credentials: 'include',
    });

    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    reviews.value = Array.isArray(data) ? data : (data?.data || []);
    error.value = null;
    console.log('Review fetched from backend:', reviews.value);
  } catch (err) {
    console.error('Failed to fetch review:', err);
    error.value = err?.message || 'Failed to fetch reviews';
    reviews.value = [];
  } finally {
    loading.value = false;
  }
}

onMounted(() => {
  fetchReviews()
})
</script>

<template>
  <div class="reviews-sidebar pa-3">
    <!-- Loading state -->
    <div v-if="loading" class="d-flex justify-center align-center" style="height: 200px;">
      <v-progress-circular indeterminate color="primary"></v-progress-circular>
    </div>

    <!-- Error state -->
    <div v-else-if="error" class="text-center pa-4">
      <v-alert type="error" variant="tonal">
        {{ error }}
      </v-alert>
      <v-btn @click="fetchReviews" variant="outlined" class="mt-2">
        Retry
      </v-btn>
    </div>

    <!-- Content -->
    <div v-else>
      <!-- Summary row with symbol + label + hyphen + count -->
      <div class="d-flex justify-space-between mb-3 align-center flex-wrap">
        <div class="d-flex align-center ga-1">
          <v-icon size="20" color="success">mdi-check-circle-outline</v-icon>
          <span class="text-body-3">Aligned - {{ counts.aligned }}</span>
        </div>
        <div class="d-flex align-center ga-1">
          <v-icon size="20" color="warning">mdi-alert-circle-outline</v-icon>
          <span class="text-body-3">Partially Aligned - {{ counts.partially }}</span>
        </div>
        <div class="d-flex align-center ga-1">
          <v-icon size="20" color="error">mdi-close-circle-outline</v-icon>
          <span class="text-body-3">Not Aligned - {{ counts.not }}</span>
        </div>
      </div>

      <!-- Exclusions header -->
      <div class="exclusions-header d-flex align-center ga-2 mb-2">
        Exclusions
      </div>

      <!-- No data state -->
      <div v-if="!reviews.length" class="text-center text-medium-emphasis pa-6">
        No reviews found for this document.
      </div>

      <!-- Exclusions list using expansion panels to mimic collapsible rows -->
      <v-expansion-panels v-else variant="accordion" density="compact">
        <v-expansion-panel v-for="r in reviews" :key="r._id || r.id">
          <v-expansion-panel-title>
            <div class="d-flex align-center ga-2">
              <v-icon :color="statusIcon(r.contract_review).color" size="16">{{ statusIcon(r.contract_review).icon }}</v-icon>
              <span class="text-body-2">{{ r.clause }}</span>
            </div>
          </v-expansion-panel-title>
          <v-expansion-panel-text>
            <div class="text-caption text-medium-emphasis mb-1">Criterion</div>
            <div class="text-body-2 mb-3">{{ r.contract_review_criterion || 'NA' }}</div>

            <div class="text-caption text-medium-emphasis mb-1">Review</div>
            <div class="text-body-2 mb-3">{{ r.contract_review_review }}</div>

            <div class="text-caption text-medium-emphasis mb-1">Recommendation</div>
            <v-alert type="warning" variant="tonal" density="compact" class="mb-2">
              <span class="recommendation-text">{{ r.contract_review_recommendation }}</span>
            </v-alert>

            <!-- <div class="d-flex ga-2">
              <v-btn size="x-small" variant="text">Rewrite</v-btn>
              <v-btn size="x-small" variant="flat" color="primary">Mark as Resolved</v-btn>
            </div> -->
          </v-expansion-panel-text>
        </v-expansion-panel>
      </v-expansion-panels>
    </div>
  </div>
</template>

<style scoped>
.reviews-sidebar {
  height: 100%;
  overflow-y: auto;
}
.flex-1-1-100 { flex: 1 1 100%; }
.recommendation-text { font-size: 12px; line-height: 1.35; }
.exclusions-header {
  font-size: 1rem;   /* bigger than default */
  font-weight: 600;  /* makes it stand out */
}
</style>

