<template>
  <div>
    <h1>Sidebar</h1>
  </div>
</template>
