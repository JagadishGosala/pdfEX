// Drawer system types converted to JavaScript
export const DrawerPosition = {
  LEFT: 'left',
  RIGHT: 'right'
};

// Interface definitions as JSDoc comments for reference
/**
 * @typedef {Object} DrawerComponent
 * @property {string} id
 * @property {any} component - Vue component
 * @property {string} icon - Material Design Icon name
 * @property {string} label
 * @property {string} position - DrawerPosition
 * @property {Record<string, any>} [props] - Optional props
 */

/**
 * @typedef {Object} DrawerState
 * @property {boolean} isOpen
 * @property {string|null} activeComponentId
 */
