import { ref, reactive } from 'vue';

// Global state for comments
const comments = ref([]);
const currentSelection = reactive({
  text: '',
  pageIndex: null,
  timestamp: null
});
const highlightedComment = ref(null);

// Load comments from localStorage
function loadComments() {
  try {
    const saved = localStorage.getItem('pdfex-comments');
    if (saved) {
      comments.value = JSON.parse(saved);
    }
  } catch (error) {
    console.error('Failed to load comments:', error);
    comments.value = [];
  }
}

// Save comments to localStorage
function saveComments() {
  try {
    localStorage.setItem('pdfex-comments', JSON.stringify(comments.value));
  } catch (error) {
    console.error('Failed to save comments:', error);
  }
}

// Add a new comment
async function addComment(commentText) {
  if (!commentText.trim() || !currentSelection.text.trim()) return;
  const comment = {
    documentId: window.__PDFEX__,
    type: 'thread',
    text: currentSelection.text,
    comment: commentText,
    pageIndex: currentSelection.pageIndex,
    textPosition: currentSelection.textPosition,
    timestamp: new Date().toISOString(),
  };
  try {
    const { csrfToken } = window;
    const headers = { 
      'Content-Type': 'application/json', 
      'X-CSRF-TOKEN': csrfToken 
    }
    const url = `/api/v2/pdfex/${window.__PDFEX__}/interactions`;
    const resp = await fetch(url, {
      method: 'POST',
      headers: headers,
      credentials: 'include',
      body: JSON.stringify(comment),
    });

    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    console.log('Comment saved on backend:', data);
    comments.value.push(data);
  } catch (err) {
    console.error('Failed to save comment:', err);
  }

  saveComments();
  
  // Don't clear selection immediately - let the component handle it
  return comment;
}

// Delete a comment
async function deleteComment(commentId) {
  const index = comments.value.findIndex(c => c.id === commentId);
  const url = `/api/v2/pdfex/${window.__PDFEX__}/interactions/${commentId}`;
  const { csrfToken } = window;
  const headers = { 
    'Content-Type': 'application/json', 
    'X-CSRF-TOKEN': csrfToken 
  }
  const resp = await fetch(url, {
    method: 'DELETE',
    headers: headers,
    credentials: 'include'
  });
  if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
  if (index > -1) {
    comments.value.splice(index, 1);
    saveComments();
  }
}

// Set current selection
function setSelection(text, pageIndex, textPosition = null) {
  currentSelection.text = text;
  currentSelection.pageIndex = pageIndex;
  currentSelection.textPosition = textPosition;
  currentSelection.timestamp = new Date().toISOString();
}

// Clear current selection
function clearSelection() {
  currentSelection.text = '';
  currentSelection.pageIndex = null;
  currentSelection.textPosition = null;
  currentSelection.timestamp = null;
}

// Get comments for a specific page
function getCommentsForPage(pageIndex) {
  return comments.value.filter(c => c.pageIndex === pageIndex);
}

// Get all comments
function getAllComments() {
  return comments.value;
}

// Highlight a specific comment
function highlightComment(commentId) {
  highlightedComment.value = commentId;
}

// Clear highlight
function clearHighlight() {
  highlightedComment.value = null;
}

export function useComments() {
  return {
    comments,
    currentSelection,
    highlightedComment,
    addComment,
    deleteComment,
    setSelection,
    clearSelection,
    getCommentsForPage,
    getAllComments,
    highlightComment,
    clearHighlight,
    loadComments,
    saveComments
  };
}
