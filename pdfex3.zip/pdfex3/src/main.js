import { createApp } from 'vue'
import App from './App.vue'

// Vuetify
import 'vuetify/styles'
import { createVuetify } from 'vuetify'
import * as components from 'vuetify/components'
import * as directives from 'vuetify/directives'
import '@mdi/font/css/materialdesignicons.css'

// Import specific components that are used
import {
  VApp,
  VLayout,
  VMain,
  VMenu,
  VBtn,
  VCard,
  VCardText,
  VCardTitle,
  VCardActions,
  VTextField,
  VCheckbox,
  VDivider,
  VChip,
  VProgressCircular,
  VTooltip,
  VNavigationDrawer,
  VBottomSheet,
  VToolbar,
  VToolbarTitle,
  VList,
  VListItem,
  VListItemTitle,
  VListItemPrepend,
  VRadioGroup,
  VRadio,
  VLabel,
  VSpacer,
  VDialog,
  VSelect,
  VSheet,
  VSubheader,
  VIcon
} from 'vuetify/components'

const vuetify = createVuetify({
  components: {
    ...components,
    VApp,
    VLayout,
    VMain,
    VMenu,
    VBtn,
    VCard,
    VCardText,
    VCardTitle,
    VCardActions,
    VTextField,
    VCheckbox,
    VDivider,
    VChip,
    VProgressCircular,
    VTooltip,
    VNavigationDrawer,
    VBottomSheet,
    VToolbar,
    VToolbarTitle,
    VList,
    VListItem,
    VListItemTitle,
    VListItemPrepend,
    VRadioGroup,
    VRadio,
    VLabel,
    VSpacer,
    VDialog,
    VSelect,
    VSheet,
    VSubheader,
    VIcon
  },
  directives,
  theme: {
    defaultTheme: 'light'
  }
})

createApp(App).use(vuetify).mount('#app')